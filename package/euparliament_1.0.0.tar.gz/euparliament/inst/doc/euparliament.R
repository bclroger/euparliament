## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

libs = c("ggplot2", "rnaturalearth", "rnaturalearthdata", "rgeos")
for (i in libs){
  if( !is.element(i, .packages(all.available = TRUE)) ) {
    install.packages(i)
  }
  library(i,character.only = TRUE)
}

library("euparliament")


## ----"loading dataset"---------------------------------------------------
results.df <- elections_eu 
results.df

## ------------------------------------------------------------------------
parties <- names(results.df[,4:length(results.df)])
parties
countries <- unique(results.df$Country)
countries

## ------------------------------------------------------------------------
results2019.df <- subset(results.df, Year == 2019, select = c("Country", "Total", "EPP", "S&D", "ALDE", "EFA", "ECR", "ENF", "EFD", "GUE", "IN", "Other"))

head(results2019.df, 10)

## ------------------------------------------------------------------------

results2014.df <- subset(results.df, Year == 2014, select = c("Country", "Total", "EPP", "S&D", "ALDE", "EFA", "ECR", "ENF", "EFD", "GUE", "IN", "Other"))

head(results2014.df, 10)

## ------------------------------------------------------------------------

gainloss.df <- results2019.df - results2014.df
gainloss.df[,1] <- countries
countryseats <- results2019.df[,2]
gainloss.df[,2] <- countryseats

head(gainloss.df, 10)

## ----"Groups"------------------------------------------------------------
groups <- list(
  "traditional" = c("EPP", "S&D"),
  "eurosceptic" = c("ECR", "ENF", "EFD"),
  "3rd" = c("ALDE", "EFA", "GUE"),
  "non_attached" = c("IN", "Other")
)
poligroups.df <- newgroupby(results.df, groups)
poligroups.df[, 'bias'] <- as.factor(
  colnames(poligroups.df[,c("traditional","eurosceptic", "3rd", "non_attached")])
  [apply(poligroups.df[,c("traditional","eurosceptic", "3rd", "non_attached")],1,which.max)]
  )

## ----"2014 group"--------------------------------------------------------
poligroups2014.df <- poligroups.df[poligroups.df$Year=="2014",]
poligroups2014.df$Year <- NULL
head(poligroups2014.df, 10)

## ----"2019 group"--------------------------------------------------------
poligroups2019.df <- poligroups.df[poligroups.df$Year=="2019",]
poligroups2019.df$Year <- NULL
head(poligroups2019.df, 10)

## ----"percentage seats"--------------------------------------------------

percresults.df <- percseats(results.df, parties)

head(percresults.df)


## ----"2014 percresults"--------------------------------------------------
percresults2014.df <- percresults.df[percresults.df$Year=="2014",]
percresults2014.df$Year <- NULL


## ----"2019 percresults"--------------------------------------------------
percresults2019.df <- percresults.df[percresults.df$Year=="2019",]
percresults2019.df$Year <- NULL


## ----"poligroups in percentages"-----------------------------------------

percpoligroups.df <- newgroupby(percresults.df, groups)

percpoligroups2014.df <- percpoligroups.df[percpoligroups.df$Year=="2014",]
percpoligroups2014.df$Year <- NULL

percpoligroups2019.df <- percpoligroups.df[percpoligroups.df$Year=="2019",]
percpoligroups2019.df$Year <- NULL

head(percpoligroups.df)


## ----gainloss in percentages---------------------------------------------

gainlossperc.df <- percchange(gainloss.df, parties)

gainlossperc.df


## ----Poligroups gainloss-------------------------------------------------

gainlosspoliperc.df <- newgroupby(gainlossperc.df, groups, "Country")

gainlosspoliperc.df


## ----'Load world data'---------------------------------------------------
world <- ne_countries(scale = "medium", returnclass = "sf")
class(world)

## ----'Define temporary working world dataset with political groups'------
t_group <- poligroups2014.df
colnames(t_group) <- 
  c(colnames(t_group)[1],
    paste(colnames(t_group[,2:length(t_group)]), '2014',sep = "_"))
t_world <- merge(world, t_group, by.x="name_long", by.y="Country")

t_group <- percpoligroups2014.df
colnames(t_group) <- 
  c(colnames(t_group)[1],
    paste(colnames(t_group[,2:length(t_group)]), '2014_perc',sep = "_"))
t_world <- merge(t_world, t_group, by.x="name_long", by.y="Country")

t_group <- poligroups2019.df
colnames(t_group) <- 
  c(colnames(t_group)[1],
    paste(colnames(t_group[,2:length(t_group)]), '2019',sep = "_"))
t_world <- merge(t_world, t_group, by.x="name_long", by.y="Country")

t_group <- percpoligroups2019.df
colnames(t_group) <- 
  c(colnames(t_group)[1],
    paste(colnames(t_group[,2:length(t_group)]), '2019_perc',sep = "_"))
t_world <- merge(t_world, t_group, by.x="name_long", by.y="Country")

t_group <- gainlosspoliperc.df
colnames(t_group) <- 
  c(colnames(t_group)[1],
    paste(colnames(t_group[,2:length(t_group)]),"perc_gl",sep = "_"))
t_world <- merge(t_world, t_group, by.x="name_long", by.y="Country")


## ----'Bias 2014', fig.width=6, fig.height=5, fig.align = "center"--------
get_map(t_world, t_world$bias_2014, title = "Major Political Group 2014")

## ----'Bias 2019', fig.width=6, fig.height=5, fig.align = "center"--------
get_map(t_world, t_world$bias_2019, title = "Major Political Group 2019")

## ----'Traditionals 2014', fig.width=6, fig.height=5, fig.align = "center"----
get_density_map(t_world, t_world$traditional_2014_perc, legend = "% of Seats", title = "Traditional 2014")

## ----'Traditionals 2019', fig.width=6, fig.height=5, fig.align = "center"----
get_density_map(t_world, t_world$traditional_2019_perc, legend = "% of Seats", title = "Traditional 2019")

## ----'Traditionals gainloss', fig.width=6, fig.height=5, fig.align = "center"----
get_density_map2(t_world, t_world$traditional_perc_gl, legend = "% of Seats", title = "Changes from 2014 to 2019 for Traditionals", gradmin = -32, gradmax = 42, gradnum = 4)

## ----'Eurospecticals 2014', fig.width=6, fig.height=5, fig.align = "center"----
get_density_map(t_world, t_world$eurosceptic_2014_perc, legend = "% of Seats", title = "Eurosceptics 2014")

## ----'Eurospecticals 2019', fig.width=6, fig.height=5, fig.align = "center"----
get_density_map(t_world, t_world$eurosceptic_2019_perc, legend = "% of Seats", title = "Eurosceptics 2019")

## ----'Eurospecticals gainloss', fig.width=6, fig.height=5, fig.align = "center"----
get_density_map2(t_world, t_world$eurosceptic_perc_gl, legend = "% of Seats", title = "Changes from 2014 to 2019 for Eurosceptics", gradmin = -32, gradmax = 42, gradnum = 4)

## ----'3rd 2014', fig.width=6, fig.height=5, fig.align = "center"---------
get_density_map(t_world, t_world$`3rd_2014_perc`, legend = "% of Seats", title = "3rd Block 2014")

## ----'3rd 2019', fig.width=6, fig.height=5, fig.align = "center"---------
get_density_map(t_world, t_world$`3rd_2019_perc`, legend = "% of Seats", title = "3rd Block 2019")

## ----'3rd gainloss', fig.width=6, fig.height=5, fig.align = "center"-----
get_density_map2(t_world, t_world$`3rd_perc_gl`, legend = "% of Seats", title = "Changes from 2014 to 2019 for 3rd Block", gradmin = -32, gradmax = 42, gradnum = 4)

## ----'Non attached 2014', fig.width=6, fig.height=5, fig.align = "center"----
get_density_map(t_world, t_world$non_attached_2014_perc, legend = "% of Seats", title = "Non-Attached 2014")

## ----'Non attached 2019', fig.width=6, fig.height=5, fig.align = "center"----
get_density_map(t_world, t_world$non_attached_2019_perc, legend = "% of Seats", title = "Non-Attached 2019")

## ----'Non attached gainloss', fig.width=6, fig.height=5, fig.align = "center"----
get_density_map2(t_world, t_world$non_attached_perc_gl, legend = "% of Seats", title = "Changes from 2014 to 2019 for Non-Attached", gradmin = -32, gradmax = 42, gradnum = 4)

